# Software Engineering Project Semester 1402
## Backend -> Amirhossein Entezari
## Frontend -> Amirali Amini
### Other members of group: Mohsen Tahmasbi, Reza Tajgozari

<br>

# How to install and run project:
However the project is available on hrm.amirentezari.ir/, you can run the application on your local machine
## 1. Clone the repo:
Clone the repo with command:
```
git clone https://github.com/Amir-Entezari/Human_Resource_backend.git
```

## 2. Run docker container
run the docker container the repo with command:
```
docker compose up
```

# How to work with the project:
On hrm.amirentezari.ir/, you can scan your qr code to checkout your enter or exit. On top of the page, you can login to see your information like checkouts, workhours, wage and etc. on hrm.amirentezari.ir/, on top of the page, you can send feedback to others and see feedbacks that others sent to you. 
In addition, a full admin panel is available on hrm-api.amirentezari.ir/admin that you can do anything you want.